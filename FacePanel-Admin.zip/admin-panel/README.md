# FacePanel Admin — Full Advanced Admin Panel

## Tech Stack
- Bootstrap 5.3.3
- Bootstrap Icons 1.11.3
- Google Fonts (Syne + DM Sans)
- Vanilla JavaScript (no jQuery)
- Pure CSS animations

## Files
```
admin-panel/
├── index.html              ← Main HTML file (open this)
└── assets/
    ├── css/
    │   └── admin.css       ← All custom styles
    └── js/
        └── admin.js        ← All interactivity
```

## Features
- Sidebar collapse / mobile drawer
- 8 Pages: Dashboard, Users, Analytics, Products, Orders, Reports, Notifications, Settings
- Stat cards with trend indicators
- Bar charts & donut chart (pure CSS/JS)
- Sortable tables with bulk select
- Tabs, Modals, Toasts, Dropdown menus
- Toggle switches
- Progress bars
- Activity timeline
- Search filter
- Export buttons
- Full Mobile & PC Responsive

## Usage
Just open `index.html` in any browser. No build step needed.

/* ============================================
   FACEPANEL ADMIN - JAVASCRIPT
   ============================================ */

// ---- SIDEBAR TOGGLE ----
const sidebar = document.getElementById('sidebar');
const topbar  = document.getElementById('topbar');
const mainContent = document.getElementById('main-content');
const toggleBtn   = document.getElementById('sidebarToggle');
const overlay     = document.getElementById('sidebarOverlay');

let isMobile = () => window.innerWidth < 992;

function toggleSidebar() {
  if (isMobile()) {
    sidebar.classList.toggle('mobile-open');
    overlay.classList.toggle('show');
  } else {
    sidebar.classList.toggle('collapsed');
    topbar.classList.toggle('expanded');
    mainContent.classList.toggle('expanded');
  }
}

if (toggleBtn) toggleBtn.addEventListener('click', toggleSidebar);
if (overlay)   overlay.addEventListener('click', () => {
  sidebar.classList.remove('mobile-open');
  overlay.classList.remove('show');
});

window.addEventListener('resize', () => {
  if (!isMobile()) {
    sidebar.classList.remove('mobile-open');
    overlay.classList.remove('show');
    topbar.classList.remove('expanded');
    mainContent.classList.remove('expanded');
    sidebar.classList.remove('collapsed');
  }
});

// ---- NAVIGATION ----
function navigate(page) {
  document.querySelectorAll('.page-section').forEach(s => s.classList.remove('active'));
  const target = document.getElementById('page-' + page);
  if (target) target.classList.add('active');

  document.querySelectorAll('#sidebar .nav-link[data-page]').forEach(l => {
    l.classList.toggle('active', l.dataset.page === page);
  });

  document.getElementById('page-title-text').textContent = pageTitles[page] || page;
  document.getElementById('page-breadcrumb').textContent = pageTitles[page] || page;

  if (isMobile()) {
    sidebar.classList.remove('mobile-open');
    overlay.classList.remove('show');
  }
}

const pageTitles = {
  dashboard: 'Dashboard', users: 'User Management', analytics: 'Analytics',
  products: 'Products', orders: 'Orders', settings: 'Settings',
  reports: 'Reports', notifications: 'Notifications'
};

document.querySelectorAll('#sidebar .nav-link[data-page]').forEach(link => {
  link.addEventListener('click', (e) => {
    e.preventDefault();
    navigate(link.dataset.page);
  });
});

// ---- SUBMENU ----
document.querySelectorAll('.has-submenu').forEach(link => {
  link.addEventListener('click', (e) => {
    e.preventDefault();
    link.classList.toggle('open');
    const sub = link.nextElementSibling;
    if (sub && sub.classList.contains('sub-nav')) sub.classList.toggle('open');
  });
});

// ---- TABS ----
document.querySelectorAll('.admin-tab').forEach(tab => {
  tab.addEventListener('click', () => {
    const group = tab.closest('.tab-group');
    const tabId = tab.dataset.tab;
    group.querySelectorAll('.admin-tab').forEach(t => t.classList.remove('active'));
    group.querySelectorAll('.tab-content').forEach(c => c.classList.remove('active'));
    tab.classList.add('active');
    const content = group.querySelector(`[data-tab-content="${tabId}"]`);
    if (content) content.classList.add('active');
  });
});

// ---- DROPDOWN ----
document.querySelectorAll('.dropdown-trigger').forEach(btn => {
  btn.addEventListener('click', (e) => {
    e.stopPropagation();
    const menu = btn.nextElementSibling;
    document.querySelectorAll('.dropdown-menu-custom.show').forEach(m => {
      if (m !== menu) m.classList.remove('show');
    });
    menu.classList.toggle('show');
  });
});
document.addEventListener('click', () => {
  document.querySelectorAll('.dropdown-menu-custom.show').forEach(m => m.classList.remove('show'));
});

// ---- MODAL ----
function openModal(id) {
  const m = document.getElementById(id);
  if (m) { m.classList.add('show'); document.body.style.overflow = 'hidden'; }
}
function closeModal(id) {
  const m = document.getElementById(id);
  if (m) { m.classList.remove('show'); document.body.style.overflow = ''; }
}
document.querySelectorAll('[data-modal-open]').forEach(btn => {
  btn.addEventListener('click', () => openModal(btn.dataset.modalOpen));
});
document.querySelectorAll('[data-modal-close]').forEach(btn => {
  btn.addEventListener('click', () => closeModal(btn.dataset.modalClose));
});
document.querySelectorAll('.admin-modal-overlay').forEach(overlay => {
  overlay.addEventListener('click', (e) => {
    if (e.target === overlay) closeModal(overlay.id);
  });
});

// ---- TOAST ----
function showToast(msg, type = 'success', icon = '✓') {
  const container = document.getElementById('toastContainer');
  const toast = document.createElement('div');
  toast.className = 'admin-toast';
  const colors = { success: 'var(--accent-green)', error: 'var(--accent-pink)', info: 'var(--accent-neon)', warn: '#ffc107' };
  toast.style.borderLeftColor = colors[type] || colors.success;
  toast.innerHTML = `<span class="toast-icon">${icon}</span><span class="toast-msg">${msg}</span><button class="toast-close" onclick="this.parentElement.remove()">✕</button>`;
  container.appendChild(toast);
  setTimeout(() => { toast.style.opacity = '0'; toast.style.transform = 'translateX(100%)'; toast.style.transition = 'all 0.3s'; setTimeout(() => toast.remove(), 300); }, 3500);
}

// ---- CHARTS (Pure CSS/JS) ----
function renderBarChart(canvasId, data, labels) {
  const wrap = document.getElementById(canvasId);
  if (!wrap) return;
  const max = Math.max(...data);
  const colors = ['#6c63ff','#00e5ff','#00ffaa','#f72585','#ff7043','#6c63ff','#00e5ff'];
  wrap.innerHTML = data.map((v, i) => `
    <div style="flex:1;display:flex;flex-direction:column;align-items:center;gap:6px;height:100%;justify-content:flex-end">
      <div style="font-size:10px;color:#8a8fa8">${v}</div>
      <div class="chart-bar" style="width:100%;height:${(v/max)*85}%;background:${colors[i%colors.length]};opacity:0.85;border-radius:6px 6px 0 0;transition:height 0.8s ease;position:relative"></div>
      <div style="font-size:10px;color:#555970;white-space:nowrap">${labels[i]||''}</div>
    </div>
  `).join('');
}

// ---- SEARCH ----
const searchInput = document.getElementById('topbarSearch');
if (searchInput) {
  searchInput.addEventListener('input', (e) => {
    const q = e.target.value.toLowerCase();
    document.querySelectorAll('.admin-table tbody tr').forEach(row => {
      const text = row.textContent.toLowerCase();
      row.style.display = text.includes(q) ? '' : 'none';
    });
  });
}

// ---- SORTABLE TABLE ----
document.querySelectorAll('.sortable-header').forEach(th => {
  th.style.cursor = 'pointer';
  th.addEventListener('click', () => {
    const table = th.closest('table');
    const index = Array.from(th.parentElement.children).indexOf(th);
    const tbody = table.querySelector('tbody');
    const rows = Array.from(tbody.querySelectorAll('tr'));
    const asc = th.dataset.sort !== 'asc';
    th.dataset.sort = asc ? 'asc' : 'desc';
    rows.sort((a, b) => {
      const av = a.cells[index]?.textContent.trim() || '';
      const bv = b.cells[index]?.textContent.trim() || '';
      return asc ? av.localeCompare(bv, undefined, { numeric: true }) : bv.localeCompare(av, undefined, { numeric: true });
    });
    rows.forEach(r => tbody.appendChild(r));
    document.querySelectorAll('.sortable-header').forEach(t => t.querySelector('.sort-icon') && (t.querySelector('.sort-icon').textContent = '↕'));
    let icon = th.querySelector('.sort-icon');
    if (!icon) { icon = document.createElement('span'); icon.className = 'sort-icon'; icon.style.marginLeft = '4px'; th.appendChild(icon); }
    icon.textContent = asc ? '↑' : '↓';
  });
});

// ---- TOGGLE SWITCH SAVE ----
document.querySelectorAll('.toggle-switch input[type=checkbox]').forEach(sw => {
  sw.addEventListener('change', () => {
    const label = sw.closest('.d-flex')?.querySelector('strong')?.textContent || 'Setting';
    showToast(`${label} ${sw.checked ? 'enabled' : 'disabled'}`, sw.checked ? 'success' : 'warn', sw.checked ? '✓' : '○');
  });
});

// ---- BULK SELECT ----
const selectAll = document.getElementById('selectAll');
if (selectAll) {
  selectAll.addEventListener('change', () => {
    document.querySelectorAll('.row-check').forEach(cb => cb.checked = selectAll.checked);
    updateBulkBar();
  });
  document.querySelectorAll('.row-check').forEach(cb => {
    cb.addEventListener('change', updateBulkBar);
  });
}
function updateBulkBar() {
  const checked = document.querySelectorAll('.row-check:checked').length;
  const bar = document.getElementById('bulkBar');
  if (bar) {
    bar.style.display = checked > 0 ? 'flex' : 'none';
    const cnt = bar.querySelector('.bulk-count');
    if (cnt) cnt.textContent = `${checked} selected`;
  }
}

// ---- INIT ----
document.addEventListener('DOMContentLoaded', () => {
  navigate('dashboard');
  renderBarChart('barChart', [65,82,47,91,73,88,55], ['Mon','Tue','Wed','Thu','Fri','Sat','Sun']);
  renderBarChart('barChart2', [42,67,55,78,90,61,74], ['Jan','Feb','Mar','Apr','May','Jun','Jul']);

  // Animate progress bars
  setTimeout(() => {
    document.querySelectorAll('.progress-fill[data-width]').forEach(el => {
      el.style.width = el.dataset.width;
    });
  }, 400);
});
